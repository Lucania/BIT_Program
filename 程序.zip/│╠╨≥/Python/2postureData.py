"""
将采集到数据中的姿态数据提取出来
"""
import linecache

data = open(r'C:\Users\Hongqing\Desktop\data.txt', 'r')  # 读方式打开采集到的数据文件
postureData = open(r'C:\Users\Hongqing\Desktop\postureData.txt', 'w')  # 写方式打开要保存的姿态数据文件
file_rows = len(data.readlines())  # 文件的行数
for i in range(1, file_rows+1):
    buff = linecache.getline(r'C:\Users\Hongqing\Desktop\data.txt', i).split(',')  # 返回每一行用","分隔的列表
    for j in range(8):  # 去除后8个与姿态无关的数据
        buff.pop(-1)
    for j in range(4):  # 去除前4个与姿态无关的数据
        buff.pop(0)

    # 写入postureData文件
    if i == file_rows:  # 文件最后一行不写入换行符
        postureData.write(','.join(str(k) for k in buff))
    else:
        postureData.write(','.join(str(k) for k in buff) + '\n')

data.close()
postureData.close()



