"""
创建UDP客户端将姿态数据发送给Unity3D进行显示
通过类似插帧的方式插入中间包，取每两相邻包的均值，在Unity3D中达到20Hz的显示效果
"""
import linecache
import socket
import struct
import time

list_former = []
list_medium = []
list_later = []

# 创建UDP客户端
client = socket.socket(type=socket.SOCK_DGRAM)
ip_port = ('127.0.0.1', 1200)
client.connect(ip_port)

f = open(r'C:\Users\Hongqing\Desktop\postureData_Filter_37.txt', 'r')
file_rows = len(f.readlines())  # 获取文件总行数

for i in range(1, file_rows):
    # 相邻两包数据，用","分割，返回一个列表/
    list_former = linecache.getline(r'C:\Users\Hongqing\Desktop\postureData_Filter_37.txt', i).split(',')
    list_later = linecache.getline(r'C:\Users\Hongqing\Desktop\postureData_Filter_37.txt', i+1).split(',')

    list_medium = []  # 进行中间包的计算
    for t in range(len(list_former)):
        list_medium.append((int(list_former[t]))/2 + (int(list_later[t]))/2)  # 将前后相邻两包的数据作平均可得到中间包的数据

    # 发送给Unity
    if i == 1:  # 在第一次发送时需要发送前面一包中间包和后一包
        client.send('AA'.encode())
        for j in list_former:
            client.send(struct.pack("!h", int(j)))
        time.sleep(0.05)
    # 第二次及以后只发送中间包和后一包
    client.send('AA'.encode())
    for j in list_medium:
        client.send(struct.pack("!h", int(j)))
    time.sleep(0.05)

    client.send('AA'.encode())
    for j in list_later:
        client.send(struct.pack("!h", int(j)))
    time.sleep(0.05)

client.close()
f.close()
