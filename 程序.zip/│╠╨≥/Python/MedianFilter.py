"""
实现对数值列表listt的中值滤波，可定义滤波核的长度n（奇数）
将列表中每一个数值和他邻域内的中值进行比较，如果绝对值的差值大于一定阈值则将该值用其邻域内的中值替换，从而消除突变
"""


def MedianFilter(listt, n=3):  # n为滤波核的长度，必须为奇数
    if not n % 2:
        return '核长度必须为奇数'

    for i in range((n-1)//2, (len(listt)-(n-1)//2)):  # 遍历整个列表
        kernel = []  # 滤波核
        for j in range(i-(n-1)//2, i+(n+1)//2):
            kernel.append(listt[j])  # 将要进行中值滤波的数值邻域内的数值放入滤波和中
            kernel.sort()            # 获取滤波核的中值
        if abs(listt[i]-kernel[(n-1)//2]) > 5000:  # 若该值与其邻域内的中值差值超过一阈值，用邻域的中值替换，实现一次中值滤波
            listt[i] = kernel[(n-1)//2]

    return listt


# 例子
list1 = [26497, 26497, 26421, 26421, 0, 26269, 262, 26194, 26194]
print(MedianFilter(list1, 3))


