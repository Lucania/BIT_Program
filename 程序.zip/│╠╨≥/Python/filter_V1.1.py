"""
利用中值滤波的方法对数据进行滤波
"""
import linecache


def MedianFilter(listt, n=3):  # n为滤波核的长度，必须为奇数
    if not n % 2:
        return '核长度必须为奇数'

    for i in range((n-1)//2, (len(listt)-(n-1)//2)):  # 遍历整个列表
        kernel = []  # 滤波核
        for j in range(i-(n-1)//2, i+(n+1)//2):
            kernel.append(listt[j])  # 将要进行中值滤波的数值邻域内的数值放入滤波和中
            kernel.sort()            # 获取滤波核的中值
        if abs(listt[i]-kernel[(n-1)//2]) > 5000:  # 若该值与其邻域内的中值差值超过一阈值，用邻域的中值替换，实现一次中值滤波
            listt[i] = kernel[(n-1)//2]

    return listt


postureData = open(r'C:\Users\Hongqing\Desktop\postureData.txt', 'r')  # 读方式打开姿态原始数据文件
postureData_Filter = open(r'C:\Users\Hongqing\Desktop\postureData_Filter.txt', 'w')  # 写方式打开滤波后姿态数据文件

file_rows = len(postureData.readlines())  # 文件的行数
# print(file_rows)

# 每包姿态数据个数4*11=44
postureData_num = len(linecache.getline(r'C:\Users\Hongqing\Desktop\postureData_Filter.txt', 1).split(','))

# 将所有时刻的所有姿态数据存储在一个二重列表(列表的元素还是列表)中
postureData_list = [[] for i in range(postureData_num)]
for i in range(1, file_rows+1):
    for j in range(postureData_num):
        line = linecache.getline(r'C:\Users\Hongqing\Desktop\postureData_Filter.txt', i).split(',')
        postureData_list[j].append(int(line[j]))

# 对列表中每一个列表元素中的数据进行中值滤波
for i in range(postureData_num):
    MedianFilter(postureData_list[i], 3)

# 将中值滤波后的数据保存到滤波后的文件中
for i in range(file_rows):
    for j in range(postureData_num):
        if j == postureData_num - 1:
            postureData_Filter.write(str(postureData_list[j][i]) + '\n')
        else:
            postureData_Filter.write(str(postureData_list[j][i]) + ',')


postureData.close()
postureData_Filter.close()
