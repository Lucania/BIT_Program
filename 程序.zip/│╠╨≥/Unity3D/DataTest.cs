﻿using UnityEngine;
using System.IO;
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public class DataTest : MonoBehaviour
{
    static public float[] pose_joint_x = new float[20];
    static public float[] pose_joint_y = new float[20];
    static public float[] pose_joint_z = new float[20];
    static public float[] pose_joint_q0 = new float[20];
    static public float[] pose_joint_q1 = new float[20];
    static public float[] pose_joint_q2 = new float[20];
    static public float[] pose_joint_q3 = new float[20];
    byte pre_cnt = 0;
    //string SaveData_Head;
    //string SaveData_Id;
    //string SaveData_X;
    //string SaveData_Y;
    //string SaveData_Z;
    //string SaveData_Check;
    //int Id;
    //int Rotation_X;
    //int Rotation_Y;
    //int Rotation_Z;
    //int SerPort_RecvQHead = 0;//指向收到的第一个数据字节
    //int SerPort_RecvQTail = 0;//指向收到的数据后面的一个空字节
    //string _txt_buf = "";
    //TxtFile RealTxtFile = new TxtFile("attdata.csv");
    public enum SocketType
    {
        TCP,
        UDP
    }
    public SocketType socketType;
    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct T_OneMember
    {
        //public UInt16 PosId;//位置编号
        public Int16 roll_q0;
        public Int16 pitch_q1;
        public Int16 yaw_q2;
        public Int16 spare_q3;
    }
    //全身数据
    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct T_BodyPosture
    {
        public byte head1;//0xAA
        public byte head2;//=0x11:QUAD;=0x22:ATT
        public byte len;//数据包长度
        public byte cnt;//发送计数，每发送一个包该值+1,用于判断重复包和丢包
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public T_OneMember[] member;
        public byte spare;//
        //public byte spare1;//
        //public byte spare2;//
        public byte check;//数据包校验和，包中除本字节外的所有字节的累加和
    }

    // Start is called before the first frame update
    void Start()
    {

        //WriteFile.console.LogStart();
        //写数据文件头
        /*
        for (int i = 0; i < 17; i++)
        {
            _txt_buf += "," + "Id,r_q0_" + i.ToString() + ",p_q1_" + i.ToString() + ",y_q2_" + i.ToString() + ",q3_" + i.ToString();
        }
        RealTxtFile.write("DateTime" + _txt_buf);
    */
    }

    /*
    void SaveData()
    {
        if(PortControl.ReceivePort != null)
        {
            SaveData_Head = PortControl.ReceivePort.Substring(0, 4);
            SaveData_Id = PortControl.ReceivePort.Substring(4, 2);
            Id = Convert.ToInt32(SaveData_Id, 16);
            SaveData_X = PortControl.ReceivePort.Substring(6, 4);
            Rotation_X = Convert.ToInt32(SaveData_X, 16);
            SaveData_Y = PortControl.ReceivePort.Substring(10, 4);
            Rotation_Y = Convert.ToInt32(SaveData_Y, 16);
            SaveData_Z = PortControl.ReceivePort.Substring(14, 4);
            Rotation_Z = Convert.ToInt32(SaveData_Z, 16);
            SaveData_Check = PortControl.ReceivePort.Substring(18, 2);
        }

    }
    */
    // Update is called once per frame
    void Update()
    {

        try
        {
            if (MoveHuman.keyboard_input == 0 || HumanPosture1.keyboard_input == true)
            {
                /*
                //get the last file name

                string pathBefore = "/Resources/JSON/";

            //analysis data from json
            string jsonTest = File.ReadAllText(Application.dataPath + pathBefore + "people_rotation.json", Encoding.UTF8);
            ModelTest obj = JsonUtility.FromJson<ModelTest>(jsonTest);

            //pervent joints return to (0,0,0)
           
            */

                //串口通信
                /*
                SaveData();
                if(SaveData_Head == "6161" && SaveData_Check=="FF")
                {

                    pose_joint_x[Id] = Rotation_X;
                    pose_joint_y[Id] = Rotation_Y;
                    pose_joint_z[Id] = Rotation_Z;
                }
                */
                //if ((SocketServer.bodyposture_recv.cnt != pre_cnt && UdpServer.bodyposture_recv.cnt == 0) || (UdpServer.bodyposture_recv.cnt != pre_cnt && SocketServer.bodyposture_recv.cnt == 0))
                //{
                    if (socketType == SocketType.UDP)
                    {
                        //UDP通信
                        //姿态角
                        if (UdpServer.bodyposture_recv.head1 == 0xAA && UdpServer.bodyposture_recv.head2 == 0x22)
                        {
                            for (int i = 0; i < 11; i++)
                            {
                                //Debug.Log("111");
                                //if (i == UdpServer.bodyposture_recv.member[i].PosId)
                                //{
                                //Debug.Log(i);
                                if (i == 0||i==1||i==7||i==8||i==9||i==10)
                                {
                                    pose_joint_x[i] = Convert.ToSingle(UdpServer.bodyposture_recv.member[i].roll_q0 * 180.0 / 32768);
                                    pose_joint_y[i] = -Convert.ToSingle(UdpServer.bodyposture_recv.member[i].yaw_q2 * 180.0 / 32768);
                                    pose_joint_z[i] = Convert.ToSingle(UdpServer.bodyposture_recv.member[i].pitch_q1 * 180.0 / 32768);
                                }
                                else if (i==2)
                                {
                                    pose_joint_x[i] = -Convert.ToSingle(UdpServer.bodyposture_recv.member[i].roll_q0 * 180.0 / 32768);
                                    pose_joint_y[i] = -Convert.ToSingle(UdpServer.bodyposture_recv.member[i].yaw_q2 * 180.0 / 32768);
                                    pose_joint_z[i] = -Convert.ToSingle(UdpServer.bodyposture_recv.member[i].pitch_q1 * 180.0 / 32768);
                                }
                                else
                                {
                                    pose_joint_x[i] = Convert.ToSingle(UdpServer.bodyposture_recv.member[i].pitch_q1 * 180.0 / 32768);
                                    pose_joint_y[i] = -Convert.ToSingle(UdpServer.bodyposture_recv.member[i].yaw_q2 * 180.0 / 32768);
                                    pose_joint_z[i] = -Convert.ToSingle(UdpServer.bodyposture_recv.member[i].roll_q0 * 180.0 / 32768);
                                }
                                    //Debug.Log(pose_joint_x[i]);
                                    //WriteCSV();
                                    //WriteFile.Log("部位 " + i+ "x " + pose_joint_x[i] + "y " + pose_joint_y[i] +"z " + pose_joint_z[i]);
                                //}
                            }
                        }
                        //四元数
                        else if (UdpServer.bodyposture_recv.head1 == 0xAA && UdpServer.bodyposture_recv.head2 == 0x11 && UdpServer.bodyposture_recv.len == 0x5E)
                        {
                            for (int i = 0; i < 11; i++)
                            {
                                //if (i == UdpServer.bodyposture_recv.member[i].PosId)
                                //{
                                    //Debug.Log(i);
                                    pose_joint_q0[i] = Convert.ToSingle(UdpServer.bodyposture_recv.member[i].roll_q0 * 180.0 / 32768);
                                    pose_joint_q1[i] = Convert.ToSingle(UdpServer.bodyposture_recv.member[i].pitch_q1 * 180.0 / 32768);
                                    pose_joint_q2[i] = Convert.ToSingle(UdpServer.bodyposture_recv.member[i].yaw_q2 * 180.0 / 32768);
                                    pose_joint_q3[i] = Convert.ToSingle(UdpServer.bodyposture_recv.member[i].spare_q3 * 180.0 / 32768);
                                    //Debug.Log(pose_joint_q3[i]);
                                    //Debug.Log(pose_joint_x[i]);
                                    //WriteCSV();
                                    //WriteFile.Log("部位 " + i+ "x " + pose_joint_x[i] + "y " + pose_joint_y[i] +"z " + pose_joint_z[i]);
                                //}
                            }
                        }
                        pre_cnt = UdpServer.bodyposture_recv.cnt;
                    }
                    else
                    {
                        //TCP通信
                        //姿态角
                        if (SocketServer.bodyposture_recv.head1 == 0xAA && SocketServer.bodyposture_recv.head2 == 0x22 && SocketServer.bodyposture_recv.len == 0x5E)
                        {
                            for (int i = 0; i < 11; i++)
                            {
                                //if (i == SocketServer.bodyposture_recv.member[i].PosId)
                                //{
                                    pose_joint_x[i] = Convert.ToSingle(SocketServer.bodyposture_recv.member[i].roll_q0 * 180.0 / 32768);
                                    pose_joint_y[i] = Convert.ToSingle(SocketServer.bodyposture_recv.member[i].pitch_q1 * 180.0 / 32768);
                                    pose_joint_z[i] = Convert.ToSingle(SocketServer.bodyposture_recv.member[i].yaw_q2 * 180.0 / 32768);
                                    Debug.Log("ID: " + i + " X: " + pose_joint_x[i] + " Y: " + pose_joint_y[i] + " Z: " + pose_joint_z[i]);
                                    //WriteCSV();
                                    //WriteFile.Log("部位 " + i+ "x " + pose_joint_x[i] + "y " + pose_joint_y[i] +"z " + pose_joint_z[i]);
                                //}
                            }
                        }
                        //四元数
                        else if (SocketServer.bodyposture_recv.head1 == 0xAA && SocketServer.bodyposture_recv.head2 == 0x11 && SocketServer.bodyposture_recv.len == 0x5E)
                        {
                            for (int i = 0; i < 11; i++)
                            {
                                //if (i == SocketServer.bodyposture_recv.member[i].PosId)
                                //{
                                    //Debug.Log(i);
                                    pose_joint_q0[i] = Convert.ToSingle(SocketServer.bodyposture_recv.member[i].roll_q0 * 180.0 / 32768);
                                    pose_joint_q1[i] = Convert.ToSingle(SocketServer.bodyposture_recv.member[i].pitch_q1 * 180.0 / 32768);
                                    pose_joint_q2[i] = Convert.ToSingle(SocketServer.bodyposture_recv.member[i].yaw_q2 * 180.0 / 32768);
                                    pose_joint_q3[i] = Convert.ToSingle(SocketServer.bodyposture_recv.member[i].spare_q3 * 180.0 / 32768);
                                    //Debug.Log(pose_joint_q3[i]);
                                    //Debug.Log(pose_joint_x[i]);
                                    //WriteCSV();
                                    //WriteFile.Log("部位 " + i+ "x " + pose_joint_x[i] + "y " + pose_joint_y[i] +"z " + pose_joint_z[i]);
                                //}
                            }
                        }
                        pre_cnt = SocketServer.bodyposture_recv.cnt;
                    }
                //}

                

            }
            /*
            else
            {
                
                pose_joint_x[0] = -21.998f;
                pose_joint_x[1] = -1.394f;
                pose_joint_x[2] = 27.421f;
                pose_joint_x[3] = -1.065f;
                pose_joint_x[4] = 46.191f;
                pose_joint_x[5] = 11.786f;
                pose_joint_x[6] = -1.065f;
                pose_joint_x[7] = 46.191f;

                pose_joint_x[8] = 11.786f;

                pose_joint_x[9] = -168.184f;

                pose_joint_x[10] = 6.386f;

                pose_joint_x[11] = -65.138f;

                pose_joint_x[12] = -168.184f;

                pose_joint_x[13] = 6.386f;

                pose_joint_x[14] = -65.138f;

                pose_joint_x[15] = -31.614f;

                pose_joint_x[16] = -31.614f;

                pose_joint_y[0] = 0;
                pose_joint_y[1] = 0;
                pose_joint_y[2] = 0;
                pose_joint_y[3] = -2.948f;

                pose_joint_y[4] = 0.138f;

                pose_joint_y[5] = -51.514f;

                pose_joint_y[6] = 2.948f;

                pose_joint_y[7] = -0.138f;

                pose_joint_y[8] = 51.514f;

                pose_joint_y[9] = -25.047f;

                pose_joint_y[10] = -26.293f;

                pose_joint_y[11] = 0;

                pose_joint_y[12] = 25.04799f;

                pose_joint_y[13] = 26.293f;

                pose_joint_y[14] = 0;

                pose_joint_y[15] = -1.77f;

                pose_joint_y[16] = 1.77f;


                pose_joint_z[0] = 0;

                pose_joint_z[1] = 0;
                pose_joint_z[2] = 0;
                pose_joint_z[3] = 38.658f;

                pose_joint_z[4] = 0.171f;

                pose_joint_z[5] = -2.643f;

                pose_joint_z[6] = -38.658f;

                pose_joint_z[7] = -0.171f;

                pose_joint_z[8] = 2.643f;

                pose_joint_z[9] = 11.57999f;

                pose_joint_z[10] = 0.406f;

                pose_joint_z[11] = 0;

                pose_joint_z[12] = -11.57999f;

                pose_joint_z[13] = -0.406f;

                pose_joint_z[14] = 0;

                pose_joint_z[15] = -0.735f;

                pose_joint_z[16] = 0.735f;

            }
            */
            //0 head
            //1 spine_03
            //2 spine_01
            //3 upperarm_l
            //4 lowerarm_l
            //5 hand_l
            //6 upperarm_r
            //7 lowerarm_r
            //8 hand_r
            //9 thigh_l
            //10 calf_l
            //11 foot_l
            //12 thigh_r
            //13 calf_r
            //14 foot_r
            //15 ball_l
            //16 ball_r



        }
        catch (ArgumentOutOfRangeException)
        {

        }

        //stay if file doesn't reach the num
        catch (FileNotFoundException)
        {
           // num = num - 1;
        }
    }

    void OnApplicationQuit()
    {
        //关闭记录文件
        //RealTxtFile.close();
        //Debug.Log("关闭记录文件");
    }
    /*
    void WriteCSV()
    {
        //写数据文件头
        _txt_buf = "";
        for (int i = 0; i < 17; i++)
        {
            _txt_buf += "," + i.ToString()
                        + "," + pose_joint_x[i].ToString()
                        + "," + pose_joint_y[i].ToString()
                        + "," + pose_joint_z[i].ToString()
                        + "," + "null";
        }
        RealTxtFile.write(DateTime.Now.ToString("hh:mm:ss.fff") + _txt_buf);
    }
    */
    /*
    public class TxtFile
    {
        string file_path_name;
        StreamWriter writer;
        UInt32 file_len = 0;//保存的数据包计数。若为0，则表示没有数据，文件可在退出时删除
        public TxtFile(string file_name)
        {
            if (Directory.Exists(System.Environment.CurrentDirectory + @"\Posture_rec"))
            {
            }
            else
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(System.Environment.CurrentDirectory + @"\Posture_rec");
                directoryInfo.Create();
            }
            string[] name = file_name.Split('.');
            file_path_name = System.Environment.CurrentDirectory + @"\Posture_rec\" + name[0] + DateTime.Now.ToString("_yyyyMMddhhmmss") + "." + name[1];
            
            //file_path_name = Application.StartupPath + @"\" + file_name + ".txt";
            //if (!File.Exists(file_path_name))
            //{
            //    writer = new StreamWriter(File.Create(file_path_name), Encoding.Default);
            //    writer.Close();
            //}
            
            writer = new StreamWriter(file_path_name, true, Encoding.Default);
        }
*/
    //    public bool bHaveData = false;//文件中有数据


    //    public void write(string str)
    //    {
    //        writer.WriteLine(str);
    //        writer.Flush();
    //        file_len++;
    //        bHaveData = true;
    //    }
    //    public void close()
    //    {
    //        writer.Close();
    //        if (!bHaveData)
    //        {
    //            if (File.Exists(file_path_name))
    //            {
    //                File.Delete(file_path_name);
    //            }
    //        }
    //    }
    //}
}
