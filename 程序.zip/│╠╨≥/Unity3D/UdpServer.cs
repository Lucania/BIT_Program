﻿
using System;
//引入库
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using UnityEngine;
using UnityEngine.UI;

public class UdpServer : MonoBehaviour
{

    //public string ipAddress = "127.0.0.1";
    public int ConnectPort = 8080;
    public InputField ServerIPinput;
    public InputField ServerPortinput;
    public Text ServerRecIPText;
    public Text ServerRecText;
    public Text ServerRec;

    //以下默认都是私有的成员
    Socket socket; //目标socket
    EndPoint clientEnd; //客户端
    IPEndPoint ipEnd; //侦听端口
    string recvStr = ""; //接收的字符串
    string sendStr; //发送的字符串
    static public byte[] recvData = new byte[1024]; //接收的数据，必须为字节
    public byte[] recvDataQ = new byte[1024];
    public byte[] posturePack = new byte[200];
    public byte recv_tmp;//从python传过来的16位高位与低位相反，利用一中间变量进行调换
    public static int head=0;
    public static int tail=0;
    byte[] sendData = new byte[1024]; //发送的数据，必须为字节
    static public int recvLen; //接收的数据长度
    Thread connectThread; //连接线程
    string text = "";
    private const int CONST_PCHUMAN_HEAD1 = 0xAA;//包头
    private const int CONST_PCHUMAN_HEAD2_QUAD = 0x11;//四元数数据包
    private const int CONST_PCHUMAN_HEAD2_ATT = 0x22;//姿态数据包
    private const int CONST_LINK_ETH = 0;//通信链路以太网
    static public DataTest.T_BodyPosture bodyposture_recv;

    //初始化
    public void InitSocket()
    {
        //WriteFile.console.LogStart();
        bodyposture_recv.member = new DataTest.T_OneMember[11];
        ConnectPort = Convert.ToInt32(ServerPortinput.text);
        //定义侦听端口,侦听任何IP
        //ipEnd = new IPEndPoint(IPAddress.Parse("10.62.151.117"), 8080);
        ipEnd = new IPEndPoint(IPAddress.Any, ConnectPort);
        //定义套接字类型,在主线程中定义
        socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        //socket = new Socket(ipEnd.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
        //socket.ExclusiveAddressUse = false;
        //服务端需要绑定ip
        socket.Bind(ipEnd);
        //定义客户端
        //clientEnd = new IPEndPoint(IPAddress.Any, 0);
        IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
        clientEnd = (EndPoint)sender;
        Debug.Log("Serverport:"+ ConnectPort  + "waiting for UDP dgram");
        ServerRec.text = "服务器已建立";
        //开启一个线程连接，必须的，否则主线程卡死
        //Loom.RunAsync(
    //() =>
    //{
        connectThread = new Thread(new ThreadStart(SocketReceive));
        //connectThread.IsBackground = true;
        connectThread.Start();
        //}
        //);
        //Debug.Log("ConnectPort"+ConnectPort);

    }

    void SocketSend(string sendStr)
    {
        //清空发送缓存
        sendData = new byte[1024];
        //数据类型转换
        sendData = Encoding.ASCII.GetBytes(sendStr);
        //发送给指定客户端
        socket.SendTo(sendData, sendData.Length, SocketFlags.None, clientEnd);
    }

   void HumanSocketRecv()
    {
        
    }
    //服务器接收
    void SocketReceive()
    {
        
        //进入接收循环
        while (true)
        {

            //clientEnd = new IPEndPoint(IPAddress.Any, 0);
            //对data清零
            recvData = new byte[1024];
            
            //获取客户端，获取客户端数据，用引用给客户端赋值
            recvLen = socket.ReceiveFrom(recvData, ref clientEnd);
            //Debug.Log("recvLen:-------"+recvLen.ToString());
            //Debug.Log(recvData[0]+"------"+recvData[1]);

            //由于接收到的16位数据高低位反了，对高位低位进行调换
            recv_tmp = recvData[0];
            recvData[0] = recvData[1];
            recvData[1] = recv_tmp;
            //Debug.Log(recvData[0] + "------" + recvData[1]);

            //Debug.Log("message from: " + clientEnd.ToString()); //打印客户端信息
            //输出接收到的数据
            Array.Copy(recvData, 0, recvDataQ, tail, recvLen);
            //Debug.Log(recvDataQ[tail].ToString() + "--------" + recvDataQ[tail + recvLen - 1].ToString());
            tail = tail+recvLen;
            //Debug.Log("tail:-------"+tail.ToString());
            if (tail>900)
            {
                head = 0;
                tail = 0;
            }

            if (tail-head>=90)//8*11(11个节点，每个节点8个字节数据)+2(2字节的包头)=90
            {
                Array.Copy(recvDataQ, head, posturePack, 0, 90);
                Array.Copy(recvDataQ, head+90, recvDataQ, 0, tail-head-90);
                tail = tail - head - 90;
                head = 0;
                UDP_RecvProc(posturePack);//对数据包进行解析
            }
            recvStr = Encoding.ASCII.GetString(recvData, 0, recvLen);
            //Debug.Log(recvStr);
            //WriteFile.Log(socket.RemoteEndPoint + ":" + recvStr);
            //Loom.QueueOnMainThread((param) =>
            //{
            //    ServerRecIPText.text = clientEnd.ToString();
            //    ServerRecText.text = recvStr;
            //}, null);
            //将接收到的数据经过处理再发送出去
            //sendStr = "From Server: " + recvStr;
            //SocketSend(sendStr);
        }
    }

    //连接关闭
    public void SocketQuit()
    {
        //关闭线程
        if (connectThread != null)
        {
            connectThread.Interrupt();
            connectThread.Abort();
        }
        //最后关闭socket
        if (socket != null)
            socket.Close();
        Debug.Log("disconnect");
        ServerRec.text = "服务器已断开";
    }

    // Use this for initialization
    void Start()
    {

        //InitSocket(); //在这里初始化server
    }


    // Update is called once per frame
    void Update()
    {
        if(recvLen != 0)
        {
            //Debug.Log(text);

            ServerRecIPText.text = clientEnd.ToString();
            //ServerRecText.text = bodyposture_recv.ToString;
        }

    }

    void OnApplicationQuit()
    {
        SocketQuit();
    }

    //对数据包进行解析，将姿态数据存入T_BodyPosture结构体中
    public void UDP_RecvProc(byte[] recvData)
    {
        //byte checksum = 0;
        //int i = 0;
        if((recvData[0]==65)&&(recvData[1] == 65))//从Python接收到的包头验证通过
        {
            //Debug.Log("65 65--------");
            bodyposture_recv.head1 = 0xAA;
            bodyposture_recv.head2 = 0x22;
            for (int j = 0; j < 11; j++)
            {
                int headcount = 2;

                //data.member[j].PosId = BitConverter.ToUInt16(buf, (headcount + 0 +(10*j)));
                bodyposture_recv.member[j].roll_q0 = BitConverter.ToInt16(recvData, (headcount + 0 + (8 * j)));
                bodyposture_recv.member[j].pitch_q1 = BitConverter.ToInt16(recvData, (headcount + 2 + (8 * j)));
                bodyposture_recv.member[j].yaw_q2 = BitConverter.ToInt16(recvData, (headcount + 4 + (8 * j)));
                bodyposture_recv.member[j].spare_q3 = BitConverter.ToInt16(recvData, (headcount + 6 + (8 * j)));
            }
            //Debug.Log("member[1].roll_q0:  "+ bodyposture_recv.member[1].roll_q0.ToString()+
            //    "  member[1].pitch_q1:  "+ bodyposture_recv.member[1].pitch_q1.ToString()+
            //    "  member[1].yaw_q2:  "+ bodyposture_recv.member[1].yaw_q2.ToString()+
            //    "  member[1].spare_q3:  " + bodyposture_recv.member[1].spare_q3.ToString()
            //    );

            ////Debug.Log("head1 complete");
            //if (recvData[2] == 0x5E)//数据包长度94字节
            //{
            //    Debug.Log("len complete");
            //    if (recvData.Length >= 94)
            //    {
            //        if ((recvData[1] == CONST_PCHUMAN_HEAD2_ATT) || (recvData[1] == CONST_PCHUMAN_HEAD2_QUAD))
            //        {
            //           // Debug.Log("head2 complete");
            //            checksum = 0;
            //            for (i = 0; i < Marshal.SizeOf(bodyposture_recv) - 1; i++)
            //            {
            //                checksum += recvData[i];
            //            }
            //            //Debug.Log("Marshal.SizeOf(bodyposture_recv)" + Marshal.SizeOf(bodyposture_recv));
            //            //Debug.Log("checksum"+checksum);
            //            //Debug.Log("data check" + recvData[Marshal.SizeOf(bodyposture_recv) - 1]);
            //            if (checksum == recvData[Marshal.SizeOf(bodyposture_recv) - 1])//校验正常
            //            {
            //                Debug.Log("complete check");
            //                Comm_RecvPack_Proc(CONST_LINK_ETH, recvData, 94);

            //                //udp_recvcnt++;
            //            }
            //        }
            //    }
            //}
            //else
            //{
            //    if (recvData.Length >= 18)
            //    {
            //        if ((recvData[0] == CONST_PCHUMAN_HEAD1)
            //            && ((recvData[1] == CONST_PCHUMAN_HEAD2_ATT) || (recvData[1] == CONST_PCHUMAN_HEAD2_QUAD)))
            //        {
            //            checksum = 0;
            //            for (i = 0; i < 18; i++)
            //            {
            //                checksum += recvData[i];
            //            }
            //            if (checksum == recvData[17])//校验正常
            //            {
            //                Comm_RecvPack_Proc(CONST_LINK_ETH, recvData, 18);
            //                //udp_recvcnt++;
            //            }
            //        }
            //    }
            //}
        }


    }
    /// <summary>
    /// 标准数据包（长度为94字节，可以是UDP，DR或BD）的处理
    /// </summary>
    /// <param name="link_type"></param>
    /// <param name="buf"></param>
    /// <param name="len"></param>
    private void Comm_RecvPack_Proc(int link_type, byte[] buf, UInt16 len)
    {
        //byte checksum = 0;
        if (buf[1] == CONST_PCHUMAN_HEAD2_ATT)//姿态数据包
        {
            ConvertPacketToCMD(ref bodyposture_recv, buf, Marshal.SizeOf(bodyposture_recv));

        }
        else if (buf[1] == CONST_PCHUMAN_HEAD2_QUAD)//四元数数据包
        {
            ConvertPacketToCMD(ref bodyposture_recv, buf, Marshal.SizeOf(bodyposture_recv));

        }
    }
    private void ConvertPacketToCMD(ref DataTest.T_BodyPosture data, byte[] buf, int len)
    {
        int headcount = 4;

        if ((recvData[1] == CONST_PCHUMAN_HEAD2_ATT)|| (recvData[1] == CONST_PCHUMAN_HEAD2_QUAD))
        {
            data.head1 = buf[0];
            data.head2 = buf[1];
            data.len = buf[2];
            data.cnt = buf[3];            
            for(int j = 0; j < 11; j++)
            {
                    //data.member[j].PosId = BitConverter.ToUInt16(buf, (headcount + 0 +(10*j)));
                    data.member[j].roll_q0 = BitConverter.ToInt16(buf, (headcount + 0 + (8 * j)));
                    data.member[j].pitch_q1 = BitConverter.ToInt16(buf, (headcount + 2 + (8 * j)));
                    data.member[j].yaw_q2 = BitConverter.ToInt16(buf, (headcount + 4 + (8 * j)));
                    data.member[j].spare_q3 = BitConverter.ToInt16(buf, (headcount + 6 + (8 * j)));
            }
            data.spare = buf[92];
            data.check = buf[93];
            //Debug.Log(data.member[4].roll_q0*180.0/32768+"  "+data.member[4].pitch_q1*180.0 / 32768 + "  "+data.member[4].yaw_q2* 180.0 / 32768 + "\n");
        }
        /*
        else
        {
            data.PCHUMAN_ROT_ATT = new DataTest.T_PCHUMAN_ROT_ATT[1];
            data.head1 = buf[0];
            data.head2 = buf[1];
            data.head3 = buf[2];
            data.check = buf[3];
            data.PCHUMAN_ROT_ATT[0].pack_id = BitConverter.ToInt32(buf, headcount + 0);
            data.PCHUMAN_ROT_ATT[0].reserved = buf[headcount + 1];
            _tmp_int16 = BitConverter.ToInt16(buf, headcount + 2);
            data.PCHUMAN_ROT_ATT[0].roll = (_tmp_int16) * 16.0 / 32768;
            _tmp_int16 = BitConverter.ToInt16(buf, headcount + 4);
            data.PCHUMAN_ROT_ATT[0].pitch = (_tmp_int16) * 16.0 / 32768;
            _tmp_int16 = BitConverter.ToInt16(buf, headcount + 6);
            data.PCHUMAN_ROT_ATT[0].yaw = (_tmp_int16) * 16.0 / 32768;
            _tmp_int16 = BitConverter.ToInt16(buf, headcount + 8);
            data.PCHUMAN_ROT_ATT[0].spare1 = (_tmp_int16) * 16.0 / 32768;
        }
        */

        return;
    }
}