﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using UnityEngine.UI;
using System.Runtime.InteropServices;

public class HumanPosture1 : MonoBehaviour
{
    #region definition
    GameObject Hips;
    GameObject LeftUpLeg;
    GameObject LeftLeg;
    GameObject LeftFoot;
    GameObject LeftToeBase;
    GameObject RightUpLeg;
    GameObject RightLeg;
    GameObject RightFoot;
    GameObject RightToeBase;
    GameObject Spine;
    GameObject Spine1;
    GameObject Spine2;
    GameObject Spine3;
    GameObject LeftShoulder;
    GameObject LeftArm;
    GameObject LeftForeArm;
    GameObject LeftHand;
    GameObject RightShoulder;
    GameObject RightArm;
    GameObject RightForeArm;
    GameObject RightHand;
    GameObject Neck1;
    GameObject Neck2;
    GameObject Head;
    static public bool keyboard_input = true;
    private string str;
    private float[] head_compensate = { 0f, 0f, 0f };
    private float[] spine_01_compensate = { 0f, 0f, 0f };//腰    
    private float[] spine_03_compensate = { 0f, 0f, 0f };//背
    private float[] upperarm_l_compensate = { 0f, 0f, 0f };
    private float[] lowerarm_l_compensate = { 0f, 0f, 0f };
    private float[] hand_l_compensate = { 0f, 0f, 0f };
    private float[] upperarm_r_compensate = { 0f, 0f, 0f };
    private float[] lowerarm_r_compensate = { 0f, 0f, 0f };
    private float[] hand_r_compensate = { 0f, 0f, 0f };
    private float[] thigh_r_compensate = { 0f, 0f, 0f };
    private float[] calf_r_compensate = { 0f, 0f, 0f };
    private float[] foot_r_compensate = { 0f, 0f, 0f };
    private float[] thigh_l_compensate = { 0f, 0f, 0f };
    private float[] calf_l_compensate = { 0f, 0f, 0f };
    private float[] foot_l_compensate = { 0f, 0f, 0f };

    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct BodyRotation
    {
        public float x;
        public float y;
        public float z;
    }
    //全身数据
    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct BodyID
    {
        public BodyRotation head;
        public BodyRotation spine_01;
        public BodyRotation spine_03;
        public BodyRotation upperarm_l;
        public BodyRotation lowerarm_l;
        public BodyRotation upperarm_r;
        public BodyRotation lowerarm_r;
        //public BodyRotation hand_l;
        //public BodyRotation hand_r;
        public BodyRotation thigh_l;
        public BodyRotation calf_l;
        public BodyRotation thigh_r;
        public BodyRotation calf_r;
        //public BodyRotation foot_l;
        //public BodyRotation foot_r;
        //public BodyRotation ball_l;
        //public BodyRotation ball_r;
    }
    static public HumanPosture1.BodyID HumanBodyID;
    Transform[] grandFa;
    #endregion

    //将场景的物体关联到该脚本中
    void InitObject()
    {
        Hips = GameObject.Find("Robot_Hips");
        LeftUpLeg = GameObject.Find("Robot_LeftUpLeg");
        LeftLeg = GameObject.Find("Robot_LeftLeg");
        LeftFoot = GameObject.Find("Robot_LeftFoot");
        LeftToeBase = GameObject.Find("Robot_LeftToeBase");
        RightUpLeg = GameObject.Find("Robot_RightUpLeg");
        RightLeg = GameObject.Find("Robot_RightLeg");
        RightFoot = GameObject.Find("Robot_RightFoot");
        RightToeBase = GameObject.Find("Robot_RightToeBase");
        Spine = GameObject.Find("Robot_Spine");
        Spine1 = GameObject.Find("Robot_Spine1");
        Spine2 = GameObject.Find("Robot_Spine2");
        Spine3 = GameObject.Find("Robot_Spine3");
        LeftShoulder = GameObject.Find("Robot_LeftShoulder");
        LeftArm = GameObject.Find("Robot_LeftArm");
        LeftForeArm = GameObject.Find("Robot_LeftForeArm");
        LeftHand = GameObject.Find("Robot_LeftHand");
        RightShoulder = GameObject.Find("Robot_RightShoulder");
        RightArm = GameObject.Find("Robot_RightArm");
        RightForeArm = GameObject.Find("Robot_RightForeArm");
        RightHand = GameObject.Find("Robot_RightHand");
        Neck1 = GameObject.Find("Robot_Neck");
        //Neck2 = GameObject.Find("Robot_Head");
        Head = GameObject.Find("Robot_Head");
    }
    // Start is called before the first frame update
    void Start()
    {
        InitObject();
        str = "重置";
        grandFa = GetComponentsInChildren<Transform>();

    }

    // Update is called once per frame
    void Update()
    {

        CorrectionValue();
        if (keyboard_input == true)
        {
            //姿态角
            if (UdpServer.bodyposture_recv.head2 == 0x22 || SocketServer.bodyposture_recv.head2 == 0x22)
            {
                //Debug.Log(DataTest.pose_joint_x[3]);
                Head.transform.eulerAngles = new Vector3(HumanBodyID.head.x, HumanBodyID.head.y, HumanBodyID.head.z);
                Spine3.transform.eulerAngles = new Vector3(HumanBodyID.spine_03.x, HumanBodyID.spine_03.y, HumanBodyID.spine_03.z);
                Spine1.transform.eulerAngles = new Vector3(HumanBodyID.spine_01.x, HumanBodyID.spine_01.y, HumanBodyID.spine_01.z);
                LeftArm.transform.eulerAngles = new Vector3(HumanBodyID.upperarm_l.x, HumanBodyID.upperarm_l.y, HumanBodyID.upperarm_l.z);
                LeftForeArm.transform.eulerAngles = new Vector3(HumanBodyID.lowerarm_l.x, HumanBodyID.lowerarm_l.y, HumanBodyID.lowerarm_l.z);
                RightArm.transform.eulerAngles = new Vector3(HumanBodyID.upperarm_r.x, HumanBodyID.upperarm_r.y, HumanBodyID.upperarm_r.z);
                RightForeArm.transform.eulerAngles = new Vector3(HumanBodyID.lowerarm_r.x, HumanBodyID.lowerarm_r.y, HumanBodyID.lowerarm_r.z);
                //LeftHand.transform.localEulerAngles = new Vector3(HumanBodyID.hand_l.x, HumanBodyID.hand_l.y, HumanBodyID.hand_l.z);
                //RightHand.transform.localEulerAngles = new Vector3(HumanBodyID.hand_r.x, HumanBodyID.hand_r.y, HumanBodyID.hand_r.z);
                LeftUpLeg.transform.eulerAngles = new Vector3(HumanBodyID.thigh_l.x, HumanBodyID.thigh_l.y, HumanBodyID.thigh_l.z);
                LeftLeg.transform.eulerAngles = new Vector3(HumanBodyID.calf_l.x, HumanBodyID.calf_l.y, HumanBodyID.calf_l.z);
                RightUpLeg.transform.eulerAngles = new Vector3(HumanBodyID.thigh_r.x, HumanBodyID.thigh_r.y, HumanBodyID.thigh_r.z);
                RightLeg.transform.eulerAngles = new Vector3(HumanBodyID.calf_r.x, HumanBodyID.calf_r.y, HumanBodyID.calf_r.z);
                //LeftFoot.transform.localEulerAngles = new Vector3(HumanBodyID.foot_l.x, HumanBodyID.foot_l.y, HumanBodyID.foot_l.z);
                //RightFoot.transform.localEulerAngles = new Vector3(HumanBodyID.foot_r.x, HumanBodyID.foot_r.y, HumanBodyID.foot_r.z);
                //LeftToeBase.transform.localEulerAngles = new Vector3(HumanBodyID.ball_l.x, HumanBodyID.ball_l.y, HumanBodyID.ball_l.z);
                //RightToeBase.transform.localEulerAngles = new Vector3(HumanBodyID.ball_r.x, HumanBodyID.ball_r.y, HumanBodyID.ball_r.z);
            }
        }
    }

    private void OnGUI()
    {
        keyboard_input = GUI.Toggle(new Rect(110, 0, 100, 100), keyboard_input, "手/自动");
        if (GUI.Button(new Rect(650, 50, 50, 30), str) && keyboard_input == false)
        {
            foreach (Transform child in grandFa)
            {
                child.transform.eulerAngles = new Vector3(0, 0, 0);
                //child.transform.localPosition = new Vector3(0, 0, 0);
            }
            /*
            Head.transform.localEulerAngles = new Vector3(0, 0, 0);
            Spine3.transform.localEulerAngles = new Vector3(0, 0, 0);
            Spine1.transform.localEulerAngles = new Vector3(0, 0, 0);
            LeftArm.transform.localEulerAngles = new Vector3(0, 0, 0);
            RightArm.transform.localEulerAngles = new Vector3(0, 0, 0);
            LeftForeArm.transform.localEulerAngles = new Vector3(0, 0, 0);
            RightForeArm.transform.localEulerAngles = new Vector3(0, 0, 0);
            LeftHand.transform.localEulerAngles = new Vector3(0, 0, 0);
            RightHand.transform.localEulerAngles = new Vector3(0, 0, 0);
            LeftUpLeg.transform.localEulerAngles = new Vector3(0, 0, 0);
            RightUpLeg.transform.localEulerAngles = new Vector3(0, 0, 0);
            LeftLeg.transform.localEulerAngles = new Vector3(0, 0, 0);
            RightLeg.transform.localEulerAngles = new Vector3(0, 0, 0);
            LeftFoot.transform.localEulerAngles = new Vector3(0, 0, 0);
            RightFoot.transform.localEulerAngles = new Vector3(0, 0, 0);
            LeftToeBase.transform.localEulerAngles = new Vector3(0, 0, 0);
            RightToeBase.transform.localEulerAngles = new Vector3(0, 0, 0);
            */
        }
        
        //标定
        if (GUI.Button(new Rect(700, 20, 100, 20), "左臂伸平") && keyboard_input == true)
        {
            //左大臂
            upperarm_l_compensate[0] = -DataTest.pose_joint_x[3];
            upperarm_l_compensate[1] = -DataTest.pose_joint_y[3];
            upperarm_l_compensate[2] = -DataTest.pose_joint_z[3];
            //左小臂
            lowerarm_l_compensate[0] = -DataTest.pose_joint_x[4];
            lowerarm_l_compensate[1] = -DataTest.pose_joint_y[4];
            lowerarm_l_compensate[2] = -DataTest.pose_joint_z[4];
            //hand_l_compensate[0] = -DataTest.pose_joint_x[5];
            //hand_l_compensate[1] = -DataTest.pose_joint_y[5];
            //hand_l_compensate[2] = -DataTest.pose_joint_z[5];
        }
        if (GUI.Button(new Rect(700, 40, 100, 20), "右臂伸平") && keyboard_input == true)
        {
            //右大臂
            upperarm_r_compensate[0] = -DataTest.pose_joint_x[5];
            upperarm_r_compensate[1] = -DataTest.pose_joint_y[5];
            upperarm_r_compensate[2] = -DataTest.pose_joint_z[5];
            //右小臂
            lowerarm_r_compensate[0] = -DataTest.pose_joint_x[6];
            lowerarm_r_compensate[1] = -DataTest.pose_joint_y[6];
            lowerarm_r_compensate[2] = -DataTest.pose_joint_z[6];
            //hand_r_compensate[0] = -DataTest.pose_joint_x[8];
            //hand_r_compensate[1] = -DataTest.pose_joint_y[8];
            //hand_r_compensate[2] = -DataTest.pose_joint_z[8];
        }
        if (GUI.Button(new Rect(700, 0, 100, 20), "躯干直立") && keyboard_input == true)
        {
            //头
            head_compensate[0] = -DataTest.pose_joint_x[0];
            head_compensate[1] = -DataTest.pose_joint_y[0];
            head_compensate[2] = -DataTest.pose_joint_z[0];
            //背
            spine_03_compensate[0] = -DataTest.pose_joint_x[1];
            spine_03_compensate[1] = -DataTest.pose_joint_y[1];
            spine_03_compensate[2] = -DataTest.pose_joint_z[1];
            //腰
            spine_01_compensate[0] = -DataTest.pose_joint_x[2];
            spine_01_compensate[1] = -DataTest.pose_joint_y[2];
            spine_01_compensate[2] = -DataTest.pose_joint_z[2];
        }
        if (GUI.Button(new Rect(700, 60, 100, 20), "左腿直立") && keyboard_input == true)
        {
            //左大腿
            thigh_l_compensate[0] = -DataTest.pose_joint_x[7];
            thigh_l_compensate[1] = -DataTest.pose_joint_y[7];
            thigh_l_compensate[2] = -DataTest.pose_joint_z[7];
            //左小腿
            calf_l_compensate[0] = -DataTest.pose_joint_x[8];
            calf_l_compensate[1] = -DataTest.pose_joint_y[8];
            calf_l_compensate[2] = -DataTest.pose_joint_z[8];
            //foot_l_compensate[0] = -DataTest.pose_joint_x[11];
            //foot_l_compensate[1] = -DataTest.pose_joint_y[11];
            //foot_l_compensate[2] = -DataTest.pose_joint_z[11];
        }
        if (GUI.Button(new Rect(700, 80, 100, 20), "右腿直立") && keyboard_input == true)
        {
            //右大腿
            thigh_r_compensate[0] = -DataTest.pose_joint_x[9];
            thigh_r_compensate[1] = -DataTest.pose_joint_y[9];
            thigh_r_compensate[2] = -DataTest.pose_joint_z[9];
            //右小腿
            calf_r_compensate[0] = -DataTest.pose_joint_x[10];
            calf_r_compensate[1] = -DataTest.pose_joint_y[10];
            calf_r_compensate[2] = -DataTest.pose_joint_z[10];
            //foot_r_compensate[0] = -DataTest.pose_joint_x[14];
            //foot_r_compensate[1] = -DataTest.pose_joint_y[14];
            //foot_r_compensate[2] = -DataTest.pose_joint_z[14];
        }
    }

    void CorrectionValue()
    {
        //头
        HumanBodyID.head.x = (DataTest.pose_joint_x[0] + head_compensate[0]);
        HumanBodyID.head.y = (DataTest.pose_joint_y[0] + head_compensate[1]);
        HumanBodyID.head.z = (DataTest.pose_joint_z[0] + head_compensate[2]);
        //背
        HumanBodyID.spine_03.x = (DataTest.pose_joint_x[1] + spine_03_compensate[0]);
        HumanBodyID.spine_03.y = (DataTest.pose_joint_y[1] + spine_03_compensate[1]);
        HumanBodyID.spine_03.z = (DataTest.pose_joint_z[1] + spine_03_compensate[2]);
        //腰
        HumanBodyID.spine_01.x = DataTest.pose_joint_x[2]+ spine_01_compensate[0];
        HumanBodyID.spine_01.y = DataTest.pose_joint_y[2]+ spine_01_compensate[1];
        HumanBodyID.spine_01.z = DataTest.pose_joint_z[2]+ spine_01_compensate[2];
        //左大臂
        HumanBodyID.upperarm_l.x = (DataTest.pose_joint_x[3] + upperarm_l_compensate[0]);
        HumanBodyID.upperarm_l.y = (DataTest.pose_joint_y[3] + upperarm_l_compensate[1]);
        HumanBodyID.upperarm_l.z = (DataTest.pose_joint_z[3] + upperarm_l_compensate[2]);
        //左小臂
        HumanBodyID.lowerarm_l.x = (DataTest.pose_joint_x[4] + lowerarm_l_compensate[0]);
        HumanBodyID.lowerarm_l.y = (DataTest.pose_joint_y[4] + lowerarm_l_compensate[1]);
        HumanBodyID.lowerarm_l.z = (DataTest.pose_joint_z[4] + lowerarm_l_compensate[2]);
        //右大臂
        HumanBodyID.upperarm_r.x = (DataTest.pose_joint_x[5] + upperarm_r_compensate[0]);
        HumanBodyID.upperarm_r.y = (DataTest.pose_joint_y[5] + upperarm_r_compensate[1]);
        HumanBodyID.upperarm_r.z = (DataTest.pose_joint_z[5] + upperarm_r_compensate[2]);
        //右小臂
        HumanBodyID.lowerarm_r.x = (DataTest.pose_joint_x[6] + lowerarm_r_compensate[0]);
        HumanBodyID.lowerarm_r.y = (DataTest.pose_joint_y[6] + lowerarm_r_compensate[1]);
        HumanBodyID.lowerarm_r.z = (DataTest.pose_joint_z[6] + lowerarm_r_compensate[2]);
        //HumanBodyID.hand_l.x = DataTest.pose_joint_x[5];
        //HumanBodyID.hand_l.y = DataTest.pose_joint_y[5];
        //HumanBodyID.hand_l.z = DataTest.pose_joint_z[5];
        //HumanBodyID.hand_r.x = DataTest.pose_joint_x[8];
        //HumanBodyID.hand_r.y = DataTest.pose_joint_y[8];
        //HumanBodyID.hand_r.z = DataTest.pose_joint_z[8];
        //左大腿
        HumanBodyID.thigh_l.x = (DataTest.pose_joint_x[7] + thigh_l_compensate[0]);
        HumanBodyID.thigh_l.y = (DataTest.pose_joint_y[7] + thigh_l_compensate[1]);
        HumanBodyID.thigh_l.z = (DataTest.pose_joint_z[7] + thigh_l_compensate[2]);
        //左小腿
        HumanBodyID.calf_l.x = (DataTest.pose_joint_x[8] + calf_l_compensate[0]);
        HumanBodyID.calf_l.y = (DataTest.pose_joint_y[8] + calf_l_compensate[1]);
        HumanBodyID.calf_l.z = (DataTest.pose_joint_z[8] + calf_l_compensate[2]);
        //右大腿
        HumanBodyID.thigh_r.x = (DataTest.pose_joint_x[9] + thigh_r_compensate[0]);
        HumanBodyID.thigh_r.y = (DataTest.pose_joint_y[9] + thigh_r_compensate[1]);
        HumanBodyID.thigh_r.z = (DataTest.pose_joint_z[9] + thigh_r_compensate[2]);
        //右小腿
        HumanBodyID.calf_r.x = (DataTest.pose_joint_x[10] + calf_r_compensate[0]);
        HumanBodyID.calf_r.y = (DataTest.pose_joint_y[10] + calf_r_compensate[1]);
        HumanBodyID.calf_r.z = (DataTest.pose_joint_z[10] + calf_r_compensate[2]);
        //HumanBodyID.foot_l.x = DataTest.pose_joint_x[11];
        //HumanBodyID.foot_l.y = DataTest.pose_joint_y[11];
        //HumanBodyID.foot_l.z = DataTest.pose_joint_z[11];
        //HumanBodyID.foot_r.x = DataTest.pose_joint_x[14];
        //HumanBodyID.foot_r.y = DataTest.pose_joint_y[14];
        //HumanBodyID.foot_r.z = DataTest.pose_joint_z[14];
        //HumanBodyID.ball_l.x = DataTest.pose_joint_x[15];
        //HumanBodyID.ball_l.y = DataTest.pose_joint_y[15];
        //HumanBodyID.ball_l.z = DataTest.pose_joint_z[15];
        //HumanBodyID.ball_r.x = DataTest.pose_joint_x[16];
        //HumanBodyID.ball_r.y = DataTest.pose_joint_y[16];
        //HumanBodyID.ball_r.z = DataTest.pose_joint_z[16];
    }
}
